class HTMLEntities
  module VERSION #:nodoc:
    MAJOR = 4
    MINOR = 3
    TINY  = 4

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
