module UNF
  VERSION = '0.2.0.beta2'
end
