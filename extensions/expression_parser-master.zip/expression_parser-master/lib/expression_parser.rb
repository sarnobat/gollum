# Taken from http://lukaszwrobel.pl/blog/math-parser-part-3-implementation
require File.join(File.dirname(__FILE__),'expression_parser/token')
require File.join(File.dirname(__FILE__),'expression_parser/lexer')
require File.join(File.dirname(__FILE__),'expression_parser/parser')
