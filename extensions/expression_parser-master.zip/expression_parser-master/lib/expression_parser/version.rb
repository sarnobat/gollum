module ExpressionParser
  VERSION = "0.9.1" unless defined?(::ExpressionParser::VERSION)
end
