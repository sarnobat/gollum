require 'rubygems'
require 'test/unit'
require 'active_support'
I18n.load_path << File.join(File.dirname(__FILE__),'locales.yml')
require File.join(File.dirname(__FILE__),'../init')
