module WikiCloth
  VERSION = "0.8.3" unless defined?(::WikiCloth::VERSION)
end
